import React from 'react'
import Routes from './router/router'
function App() {
  return (
    <div className="App">
      <Routes />
    </div>
  );
}

export default App;
