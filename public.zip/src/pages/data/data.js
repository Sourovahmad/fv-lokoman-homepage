const TheButtonsData = [
    {
        titlerow1: 'Kiosk',
        titlerow2: 'Medizinische Fußpflege',
        sourceL1: '/kategorian',
        sourceL2: '/'
    },
    {
        titlerow1: 'Friseur',
        titlerow2: 'Medizinische Fußpflege',
        sourceL1: '/',
        sourceL2: '/'
    },
    {
        titlerow1: 'Seelsorge',
        titlerow2: 'Medizinische Fußpflege',
        sourceL1: '/',
        sourceL2: '/'
    }

]
export { TheButtonsData }

